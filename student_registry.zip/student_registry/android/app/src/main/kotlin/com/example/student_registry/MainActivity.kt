package com.example.student_registry

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
