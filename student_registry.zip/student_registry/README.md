# student_registry

A new Flutter project.
